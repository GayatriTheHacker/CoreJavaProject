
package com.stech.newStudentInfo;

// POJO - Plain Old Java Object
public class StudentIdCard {

	// POJO private Data Member
	private String studID;
	private String studFullName;
	private String studClass;
	private String studBloodGrp;
	private String dateOfBirth;

	// Constructor(Parameterized)
	public StudentIdCard(String studID, String studFullName, String studClass, String studBloodGrp,
			String dateOfBirth) {
		super();
		this.studID = studID;
		this.studFullName = studFullName;
		this.studClass = studClass;
		this.studBloodGrp = studBloodGrp;
		this.dateOfBirth = dateOfBirth;
	}
	
    public void diplayStudnetIdDetails() {
		System.out.println();
		System.out.println();
		System.out.println("\t \t *************STUDENT ID CARD************");
		System.out.println("\t \t * Student ID \t \t : " + studID + "\t" + "*");
		System.out.println("\t \t * Student Name \t : " + studFullName + "\t" + "*");
		System.out.println("\t \t * Student Class \t : " + studClass + "\t \t" + "*");
		System.out.println("\t \t * Blood Group \t \t : " + studBloodGrp + "\t \t" + "*");
		System.out.println("\t \t * Date Of Birth \t : " + dateOfBirth + "\t" + "*");
		System.out.println("\t \t ****************************************");
	}
}
